var annotated_dup =
[
    [ "Communicative", "class_communicative.html", "class_communicative" ],
    [ "Data", "struct_data.html", "struct_data" ],
    [ "DataSource", "class_data_source.html", "class_data_source" ],
    [ "Identifiable", "class_identifiable.html", "class_identifiable" ],
    [ "Identity", "struct_identity.html", "struct_identity" ],
    [ "Instructable", "class_instructable.html", "class_instructable" ],
    [ "Instructor", "class_instructor.html", "class_instructor" ],
    [ "mCmd", "structm_cmd.html", "structm_cmd" ],
    [ "sCmd", "structs_cmd.html", "structs_cmd" ],
    [ "Sensor", "class_sensor.html", "class_sensor" ]
];