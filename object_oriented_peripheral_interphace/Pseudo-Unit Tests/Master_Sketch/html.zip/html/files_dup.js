var files_dup =
[
    [ "Communicative.cpp", "_communicative_8cpp.html", "_communicative_8cpp" ],
    [ "Communicative.h", "_communicative_8h.html", [
      [ "Communicative", "class_communicative.html", "class_communicative" ]
    ] ],
    [ "DataSource.cpp", "_data_source_8cpp.html", null ],
    [ "DataSource.h", "_data_source_8h.html", [
      [ "DataSource", "class_data_source.html", "class_data_source" ]
    ] ],
    [ "Identifiable.cpp", "_identifiable_8cpp.html", null ],
    [ "Identifiable.h", "_identifiable_8h.html", [
      [ "Identifiable", "class_identifiable.html", "class_identifiable" ]
    ] ],
    [ "Instructable.cpp", "_instructable_8cpp.html", null ],
    [ "Instructable.h", "_instructable_8h.html", [
      [ "Instructable", "class_instructable.html", "class_instructable" ]
    ] ],
    [ "Instructor.cpp", "_instructor_8cpp.html", null ],
    [ "Instructor.h", "_instructor_8h.html", [
      [ "Instructor", "class_instructor.html", "class_instructor" ]
    ] ],
    [ "Sensor.cpp", "_sensor_8cpp.html", null ],
    [ "Sensor.h", "_sensor_8h.html", [
      [ "Sensor", "class_sensor.html", "class_sensor" ]
    ] ],
    [ "SPI_Anything.h", "_s_p_i___anything_8h.html", "_s_p_i___anything_8h" ],
    [ "SPI_InstructionSet.h", "_s_p_i___instruction_set_8h.html", "_s_p_i___instruction_set_8h" ]
];