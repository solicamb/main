var searchData=
[
  ['nak',['NAK',['../_s_p_i___anything_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47a5d6a7bf7f9dbd450f30e49215185fcb2',1,'NAK():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47a5d6a7bf7f9dbd450f30e49215185fcb2',1,'NAK():&#160;SPI_InstructionSet.h']]],
  ['namelength',['namelength',['../struct_identity.html#a4232dacf1ace14d82b3fa90b71bf6f17',1,'Identity']]],
  ['nextcommandplease',['NextCommandPlease',['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792a9319f300f7a4bc8e0c2c9139cde4fb21',1,'NextCommandPlease():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792a9319f300f7a4bc8e0c2c9139cde4fb21',1,'NextCommandPlease():&#160;SPI_InstructionSet.h']]],
  ['no',['No',['../_s_p_i___anything_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47a996e257033c09daf66076efc1ebd3b1c',1,'No():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47a996e257033c09daf66076efc1ebd3b1c',1,'No():&#160;SPI_InstructionSet.h']]],
  ['number_5fof_5fdata_5frows',['NUMBER_OF_DATA_ROWS',['../_s_p_i___instruction_set_8h.html#a030a0b94acdc35db8cf20a5044a1c775',1,'SPI_InstructionSet.h']]],
  ['numcolumns',['NumColumns',['../struct_data.html#adc9b9e04d61f3943cd590cc96fe9df83',1,'Data::NumColumns()'],['../struct_data.html#ab7ad5d3d8f1e4b3f42c5aedb1e74b336',1,'Data::NumColumns()']]],
  ['numrows',['NumRows',['../struct_data.html#ab07bb3357ea297d5edb0cf5b79efb6cb',1,'Data::NumRows()'],['../struct_data.html#ac0883de785701631da0e099578c748ca',1,'Data::NumRows()']]]
];
