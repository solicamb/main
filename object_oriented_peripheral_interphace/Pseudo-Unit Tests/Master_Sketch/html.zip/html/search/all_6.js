var searchData=
[
  ['hasidentitychanged',['hasIdentityChanged',['../class_identifiable.html#adbc1a3f62e543a0df002a43413998a26',1,'Identifiable']]],
  ['howlongshouldiwait',['howLongShouldIWait',['../class_instructor.html#a2e9afbb8e6ce1c671e8e9dc29cf4715f',1,'Instructor::howLongShouldIWait()'],['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792abd3b3ed0c9b543b6cf7ff2463568fe4f',1,'HowLongShouldIWait():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792abd3b3ed0c9b543b6cf7ff2463568fe4f',1,'HowLongShouldIWait():&#160;SPI_InstructionSet.h']]],
  ['howmanyinstructions',['howManyInstructions',['../class_instructor.html#abfe73e27d6364bf5cad80f30f6833ec8',1,'Instructor::howManyInstructions()'],['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792a303b60d37143112142046add7f73d4bf',1,'HowManyInstructions():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792a303b60d37143112142046add7f73d4bf',1,'HowManyInstructions():&#160;SPI_InstructionSet.h']]]
];
