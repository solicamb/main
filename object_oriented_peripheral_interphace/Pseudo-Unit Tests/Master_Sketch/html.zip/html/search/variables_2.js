var searchData=
[
  ['identity_5fsensor_5fname_5flength',['IDENTITY_SENSOR_NAME_LENGTH',['../_s_p_i___instruction_set_8h.html#addd001d124aca0fe92b3e484732fb7c8',1,'SPI_InstructionSet.h']]],
  ['instruction',['Instruction',['../structs_cmd.html#ae44f8e2a61a9d80037ef1379815d51cc',1,'sCmd::Instruction()'],['../structm_cmd.html#a7adb91eb9d020c0f2650e99a857d2c3d',1,'mCmd::Instruction()']]],
  ['iparam',['iParam',['../structs_cmd.html#a4d0a4aab326d0ba8eb8128adb61c0888',1,'sCmd::iParam()'],['../structm_cmd.html#a4d0a4aab326d0ba8eb8128adb61c0888',1,'mCmd::iParam()']]]
];
