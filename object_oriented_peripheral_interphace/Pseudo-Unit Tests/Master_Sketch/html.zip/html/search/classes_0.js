var searchData=
[
  ['communicative',['Communicative',['../class_communicative.html',1,'']]]
];
