var searchData=
[
  ['sensor',['Sensor',['../class_sensor.html#a370005d04d3566c21b9190e1442fa4e8',1,'Sensor']]],
  ['spi_5freadanything',['SPI_readAnything',['../_s_p_i___anything_8h.html#a41fb54443a978259231a2372acbac533',1,'SPI_Anything.h']]],
  ['spi_5freadanything_5fisr',['SPI_readAnything_ISR',['../_s_p_i___anything_8h.html#a30a371444889e1bb6f53b8b514b79f28',1,'SPI_Anything.h']]],
  ['spi_5fwriteanything',['SPI_writeAnything',['../_s_p_i___anything_8h.html#a2c85fd19454067374c4f7a21e7ec44bf',1,'SPI_Anything.h']]],
  ['startmeasurement',['StartMeasurement',['../class_sensor.html#af0e64874a3d1b8ae19e3b623d244342a',1,'Sensor']]]
];
