var searchData=
[
  ['refertofloat',['ReferToFloat',['../_s_p_i___anything_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47a3919733d70c696dca64417af443ad6c6',1,'ReferToFloat():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47a3919733d70c696dca64417af443ad6c6',1,'ReferToFloat():&#160;SPI_InstructionSet.h']]],
  ['refertoint',['ReferToInt',['../_s_p_i___anything_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47ac5878118d3538835789584340c0d2eaa',1,'ReferToInt():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47ac5878118d3538835789584340c0d2eaa',1,'ReferToInt():&#160;SPI_InstructionSet.h']]],
  ['refertostring',['ReferToString',['../_s_p_i___anything_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47a05d96a660820bb9f0681a045c5e4a884',1,'ReferToString():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47a05d96a660820bb9f0681a045c5e4a884',1,'ReferToString():&#160;SPI_InstructionSet.h']]],
  ['request_5fdelay_5fmicros',['REQUEST_DELAY_MICROS',['../_communicative_8cpp.html#a5c3f0e72a46203dc1f8b28ba0c40bfb3',1,'Communicative.cpp']]],
  ['requestdata',['RequestData',['../class_communicative.html#a0a56aaa3248edae66ccb13cbf2bf156a',1,'Communicative']]],
  ['requestidentity',['RequestIdentity',['../class_communicative.html#a01ee3d76d85bad6123c4d4f6262c6c2d',1,'Communicative']]],
  ['requestreply',['RequestReply',['../class_communicative.html#a4fe112ad5a3d693e39ae44dd43eaf0c1',1,'Communicative']]],
  ['resetdevice',['ResetDevice',['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792a87079e73086d12bc4001e38b3427fc5d',1,'ResetDevice():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792a87079e73086d12bc4001e38b3427fc5d',1,'ResetDevice():&#160;SPI_InstructionSet.h']]],
  ['restartmeasurement',['RestartMeasurement',['../class_sensor.html#ad58e9acfc23f07af433f0e2596d786d7',1,'Sensor']]],
  ['restartmeasurementprocedure',['RestartMeasurementProcedure',['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792a4ad074804da746cc861dbb972ac48a22',1,'RestartMeasurementProcedure():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792a4ad074804da746cc861dbb972ac48a22',1,'RestartMeasurementProcedure():&#160;SPI_InstructionSet.h']]],
  ['row_5fheading_5flength',['ROW_HEADING_LENGTH',['../_s_p_i___instruction_set_8h.html#a63a97a0fe356d1b3030dfb633e0d0b8e',1,'SPI_InstructionSet.h']]],
  ['row_5funit_5flength',['ROW_UNIT_LENGTH',['../_s_p_i___instruction_set_8h.html#af45194e4246701e52a2d67f27cc3ffb8',1,'SPI_InstructionSet.h']]],
  ['rowheadings',['RowHeadings',['../struct_data.html#acdeeed923c026497e7c1e0dee0ebd85b',1,'Data']]],
  ['rowunits',['rowUnits',['../struct_data.html#ae28c8037946b702ba5fbb93da5cb43e5',1,'Data']]]
];
