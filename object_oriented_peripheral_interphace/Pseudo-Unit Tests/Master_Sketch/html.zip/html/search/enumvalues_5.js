var searchData=
[
  ['istheredata',['IsThereData',['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792ae0e86116c94ee3a2de08c331a25a9553',1,'IsThereData():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792ae0e86116c94ee3a2de08c331a25a9553',1,'IsThereData():&#160;SPI_InstructionSet.h']]]
];
