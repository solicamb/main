var searchData=
[
  ['pausemeasurementformillis',['PauseMeasurementForMillis',['../class_sensor.html#afdcc3b63357bd24f519e0cbc85454a52',1,'Sensor']]]
];
