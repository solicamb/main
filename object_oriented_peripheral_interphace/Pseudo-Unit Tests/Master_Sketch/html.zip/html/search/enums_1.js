var searchData=
[
  ['sinstruct',['sInstruct',['../_s_p_i___anything_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47',1,'sInstruct():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47',1,'sInstruct():&#160;SPI_InstructionSet.h']]]
];
