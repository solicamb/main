var searchData=
[
  ['communicative',['Communicative',['../class_communicative.html',1,'Communicative'],['../class_communicative.html#aa92e21c2c2b3ee8dda993872f6b0c73a',1,'Communicative::Communicative()']]],
  ['communicative_2ecpp',['Communicative.cpp',['../_communicative_8cpp.html',1,'']]],
  ['communicative_2eh',['Communicative.h',['../_communicative_8h.html',1,'']]]
];
