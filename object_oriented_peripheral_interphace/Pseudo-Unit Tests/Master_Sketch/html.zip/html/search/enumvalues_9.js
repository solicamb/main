var searchData=
[
  ['second',['Second',['../_s_p_i___instruction_set_8h.html#a9d8048399836e11887f85cc8dc3d75d5a6ca36e4a4a4052597a28b219baf6576f',1,'SPI_InstructionSet.h']]],
  ['senddataplease',['SendDataPlease',['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792a9972e8050301ea3d5b585bc557bac507',1,'SendDataPlease():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792a9972e8050301ea3d5b585bc557bac507',1,'SendDataPlease():&#160;SPI_InstructionSet.h']]],
  ['sitrep',['SitRep',['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792a7b437edd37dcf8f275dea91b2d3dae70',1,'SitRep():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792a7b437edd37dcf8f275dea91b2d3dae70',1,'SitRep():&#160;SPI_InstructionSet.h']]]
];
