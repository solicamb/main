var searchData=
[
  ['whoareyou',['WhoAreYou',['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792a4b25a74b6be49faf4a9356e1565a4b25',1,'WhoAreYou():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792a4b25a74b6be49faf4a9356e1565a4b25',1,'WhoAreYou():&#160;SPI_InstructionSet.h']]]
];
