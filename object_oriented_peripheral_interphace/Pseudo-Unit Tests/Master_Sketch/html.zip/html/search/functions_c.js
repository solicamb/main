var searchData=
[
  ['transferandwait',['transferAndWait',['../_s_p_i___anything_8h.html#a8d9573ea9baf01dc9ebab92eb66fed9e',1,'SPI_Anything.h']]]
];
