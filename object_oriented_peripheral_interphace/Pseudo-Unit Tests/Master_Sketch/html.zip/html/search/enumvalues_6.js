var searchData=
[
  ['nak',['NAK',['../_s_p_i___anything_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47a5d6a7bf7f9dbd450f30e49215185fcb2',1,'NAK():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47a5d6a7bf7f9dbd450f30e49215185fcb2',1,'NAK():&#160;SPI_InstructionSet.h']]],
  ['nextcommandplease',['NextCommandPlease',['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792a9319f300f7a4bc8e0c2c9139cde4fb21',1,'NextCommandPlease():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792a9319f300f7a4bc8e0c2c9139cde4fb21',1,'NextCommandPlease():&#160;SPI_InstructionSet.h']]],
  ['no',['No',['../_s_p_i___anything_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47a996e257033c09daf66076efc1ebd3b1c',1,'No():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#a949ec019a0f52780dcdd7d5a5ba73e47a996e257033c09daf66076efc1ebd3b1c',1,'No():&#160;SPI_InstructionSet.h']]]
];
