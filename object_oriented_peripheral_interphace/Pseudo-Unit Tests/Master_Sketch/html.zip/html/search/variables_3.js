var searchData=
[
  ['namelength',['namelength',['../struct_identity.html#a4232dacf1ace14d82b3fa90b71bf6f17',1,'Identity']]],
  ['number_5fof_5fdata_5frows',['NUMBER_OF_DATA_ROWS',['../_s_p_i___instruction_set_8h.html#a030a0b94acdc35db8cf20a5044a1c775',1,'SPI_InstructionSet.h']]],
  ['numcolumns',['NumColumns',['../struct_data.html#adc9b9e04d61f3943cd590cc96fe9df83',1,'Data::NumColumns()'],['../struct_data.html#ab7ad5d3d8f1e4b3f42c5aedb1e74b336',1,'Data::NumColumns()']]],
  ['numrows',['NumRows',['../struct_data.html#ab07bb3357ea297d5edb0cf5b79efb6cb',1,'Data::NumRows()'],['../struct_data.html#ac0883de785701631da0e099578c748ca',1,'Data::NumRows()']]]
];
