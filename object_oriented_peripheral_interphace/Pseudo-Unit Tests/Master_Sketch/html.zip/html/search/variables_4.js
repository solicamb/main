var searchData=
[
  ['request_5fdelay_5fmicros',['REQUEST_DELAY_MICROS',['../_communicative_8cpp.html#a5c3f0e72a46203dc1f8b28ba0c40bfb3',1,'Communicative.cpp']]],
  ['row_5fheading_5flength',['ROW_HEADING_LENGTH',['../_s_p_i___instruction_set_8h.html#a63a97a0fe356d1b3030dfb633e0d0b8e',1,'SPI_InstructionSet.h']]],
  ['row_5funit_5flength',['ROW_UNIT_LENGTH',['../_s_p_i___instruction_set_8h.html#af45194e4246701e52a2d67f27cc3ffb8',1,'SPI_InstructionSet.h']]],
  ['rowheadings',['RowHeadings',['../struct_data.html#acdeeed923c026497e7c1e0dee0ebd85b',1,'Data']]],
  ['rowunits',['rowUnits',['../struct_data.html#ae28c8037946b702ba5fbb93da5cb43e5',1,'Data']]]
];
