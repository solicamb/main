var searchData=
[
  ['updateidentity',['updateIdentity',['../class_identifiable.html#ae99f8914426041ea02932d0ed00b29c3',1,'Identifiable']]]
];
