var searchData=
[
  ['howlongshouldiwait',['HowLongShouldIWait',['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792abd3b3ed0c9b543b6cf7ff2463568fe4f',1,'HowLongShouldIWait():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792abd3b3ed0c9b543b6cf7ff2463568fe4f',1,'HowLongShouldIWait():&#160;SPI_InstructionSet.h']]],
  ['howmanyinstructions',['HowManyInstructions',['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792a303b60d37143112142046add7f73d4bf',1,'HowManyInstructions():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792a303b60d37143112142046add7f73d4bf',1,'HowManyInstructions():&#160;SPI_InstructionSet.h']]]
];
