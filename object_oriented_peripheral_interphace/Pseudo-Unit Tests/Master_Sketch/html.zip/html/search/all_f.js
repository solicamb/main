var searchData=
[
  ['third',['Third',['../_s_p_i___instruction_set_8h.html#a9d8048399836e11887f85cc8dc3d75d5a0dd6aa89f0ae76a3c80d4ad8919a4828',1,'SPI_InstructionSet.h']]],
  ['transferandwait',['transferAndWait',['../_s_p_i___anything_8h.html#a8d9573ea9baf01dc9ebab92eb66fed9e',1,'SPI_Anything.h']]]
];
