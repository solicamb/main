var searchData=
[
  ['requestdata',['RequestData',['../class_communicative.html#a0a56aaa3248edae66ccb13cbf2bf156a',1,'Communicative']]],
  ['requestidentity',['RequestIdentity',['../class_communicative.html#a01ee3d76d85bad6123c4d4f6262c6c2d',1,'Communicative']]],
  ['requestreply',['RequestReply',['../class_communicative.html#a4fe112ad5a3d693e39ae44dd43eaf0c1',1,'Communicative']]],
  ['restartmeasurement',['RestartMeasurement',['../class_sensor.html#ad58e9acfc23f07af433f0e2596d786d7',1,'Sensor']]]
];
