var searchData=
[
  ['sensorchipselect',['sensorChipSelect',['../struct_identity.html#a219419d57e4c4e0d53ddcb44af330f32',1,'Identity']]],
  ['sensorid',['sensorID',['../struct_identity.html#a4f5a5e2cb7ee061dd0bd29b7086d89ac',1,'Identity']]],
  ['sensorname',['SensorName',['../struct_identity.html#a8312ce3b92270e7548eba232df2b90a6',1,'Identity']]],
  ['slave_5fcommmand_5fstring_5flength',['SLAVE_COMMMAND_STRING_LENGTH',['../_s_p_i___instruction_set_8h.html#afb2f23f8980c03317ec47ce151335ec7',1,'SPI_InstructionSet.h']]],
  ['sparam',['sParam',['../structs_cmd.html#aba4b0fff96810260e09a5aa9a19b730d',1,'sCmd']]]
];
