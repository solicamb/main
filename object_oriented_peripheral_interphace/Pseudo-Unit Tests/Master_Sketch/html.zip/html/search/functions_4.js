var searchData=
[
  ['hasidentitychanged',['hasIdentityChanged',['../class_identifiable.html#adbc1a3f62e543a0df002a43413998a26',1,'Identifiable']]],
  ['howlongshouldiwait',['howLongShouldIWait',['../class_instructor.html#a2e9afbb8e6ce1c671e8e9dc29cf4715f',1,'Instructor']]],
  ['howmanyinstructions',['howManyInstructions',['../class_instructor.html#abfe73e27d6364bf5cad80f30f6833ec8',1,'Instructor']]]
];
