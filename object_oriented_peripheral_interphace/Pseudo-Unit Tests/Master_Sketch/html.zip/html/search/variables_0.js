var searchData=
[
  ['data_5frow_5flength',['DATA_ROW_LENGTH',['../_s_p_i___instruction_set_8h.html#afaade7aab877c51eaea08012fa5a7ce2',1,'SPI_InstructionSet.h']]],
  ['datapoints',['DataPoints',['../struct_data.html#a68309a60af5d6b6855ae31c874b71ffe',1,'Data']]]
];
