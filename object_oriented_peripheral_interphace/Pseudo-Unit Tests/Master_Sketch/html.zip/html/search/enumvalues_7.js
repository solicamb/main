var searchData=
[
  ['pausemeasurementforiparam',['PauseMeasurementForiParam',['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792a965f2ec6e1a55050b8bccd7063f904b3',1,'PauseMeasurementForiParam():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792a965f2ec6e1a55050b8bccd7063f904b3',1,'PauseMeasurementForiParam():&#160;SPI_InstructionSet.h']]]
];
