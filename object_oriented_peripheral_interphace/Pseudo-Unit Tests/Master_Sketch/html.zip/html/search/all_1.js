var searchData=
[
  ['beginmeasurement',['BeginMeasurement',['../_s_p_i___anything_8h.html#afefab269eb3692ecb3e5fcdbb9440792a95e0f581b12f62fe8be32f5f50b8381e',1,'BeginMeasurement():&#160;SPI_Anything.h'],['../_s_p_i___instruction_set_8h.html#afefab269eb3692ecb3e5fcdbb9440792a95e0f581b12f62fe8be32f5f50b8381e',1,'BeginMeasurement():&#160;SPI_InstructionSet.h']]]
];
