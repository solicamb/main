var indexSectionsWithContent =
{
  0: "abcdfghilmnoprstuwy~",
  1: "cdims",
  2: "cdis",
  3: "acdghilmoprstu~",
  4: "dfinrs",
  5: "ms",
  6: "abdfhinprstwy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator"
};

