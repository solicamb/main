var class_identifiable =
[
    [ "Identifiable", "class_identifiable.html#a107ce612ee60e9be98085abdfbfdc83e", null ],
    [ "getIDNumber", "class_identifiable.html#a85d8439d79bd15eeb1c40d694d3d49ae", null ],
    [ "getSensorName", "class_identifiable.html#a7942e337c1303ce42cc822032465c66a", null ],
    [ "hasIdentityChanged", "class_identifiable.html#adbc1a3f62e543a0df002a43413998a26", null ],
    [ "updateIdentity", "class_identifiable.html#ae99f8914426041ea02932d0ed00b29c3", null ]
];