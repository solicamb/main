var hierarchy =
[
    [ "Communicative", "class_communicative.html", null ],
    [ "Data", "struct_data.html", null ],
    [ "DataSource", "class_data_source.html", [
      [ "Sensor", "class_sensor.html", null ]
    ] ],
    [ "Identifiable", "class_identifiable.html", [
      [ "Sensor", "class_sensor.html", null ]
    ] ],
    [ "Identity", "struct_identity.html", null ],
    [ "Instructable", "class_instructable.html", [
      [ "Sensor", "class_sensor.html", null ]
    ] ],
    [ "Instructor", "class_instructor.html", [
      [ "Sensor", "class_sensor.html", null ]
    ] ],
    [ "mCmd", "structm_cmd.html", null ],
    [ "sCmd", "structs_cmd.html", null ]
];