var class_sensor =
[
    [ "Sensor", "class_sensor.html#a370005d04d3566c21b9190e1442fa4e8", null ],
    [ "PauseMeasurementForMillis", "class_sensor.html#afdcc3b63357bd24f519e0cbc85454a52", null ],
    [ "RestartMeasurement", "class_sensor.html#ad58e9acfc23f07af433f0e2596d786d7", null ],
    [ "StartMeasurement", "class_sensor.html#af0e64874a3d1b8ae19e3b623d244342a", null ]
];