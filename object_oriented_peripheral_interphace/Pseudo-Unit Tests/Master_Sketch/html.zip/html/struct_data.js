var struct_data =
[
    [ "operator=", "struct_data.html#a3ae506c712bc36c15533f5499608a047", null ],
    [ "operator=", "struct_data.html#a7c50ba562a0dcddc5ca2c733f1bbcb61", null ],
    [ "DataPoints", "struct_data.html#a68309a60af5d6b6855ae31c874b71ffe", null ],
    [ "NumColumns", "struct_data.html#adc9b9e04d61f3943cd590cc96fe9df83", null ],
    [ "NumColumns", "struct_data.html#ab7ad5d3d8f1e4b3f42c5aedb1e74b336", null ],
    [ "NumRows", "struct_data.html#ab07bb3357ea297d5edb0cf5b79efb6cb", null ],
    [ "NumRows", "struct_data.html#ac0883de785701631da0e099578c748ca", null ],
    [ "RowHeadings", "struct_data.html#acdeeed923c026497e7c1e0dee0ebd85b", null ],
    [ "rowUnits", "struct_data.html#ae28c8037946b702ba5fbb93da5cb43e5", null ]
];