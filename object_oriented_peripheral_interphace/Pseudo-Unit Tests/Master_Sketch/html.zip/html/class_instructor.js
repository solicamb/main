var class_instructor =
[
    [ "Instructor", "class_instructor.html#afd38d621d3d07ecb0e9c7f522a1b1823", null ],
    [ "getCurrentCommandFloat", "class_instructor.html#ae81f8123893b582fd32a71601471cff8", null ],
    [ "getCurrentCommandInstruction", "class_instructor.html#a1e54d05ded7ecf88f0205b52901df681", null ],
    [ "getCurrentCommandInt", "class_instructor.html#adcbf1cb6d2739539465edc6d996d2987", null ],
    [ "getCurrentCommandString", "class_instructor.html#a8c66f480a7b5a6b434f613bc7197e824", null ],
    [ "howLongShouldIWait", "class_instructor.html#a2e9afbb8e6ce1c671e8e9dc29cf4715f", null ],
    [ "howManyInstructions", "class_instructor.html#abfe73e27d6364bf5cad80f30f6833ec8", null ],
    [ "loadNextCommand", "class_instructor.html#a43cbe18547a30108219f3aa2945fc9ca", null ]
];