var struct_identity =
[
    [ "operator=", "struct_identity.html#ae7ccf6e408df14fac9dc856f53d81718", null ],
    [ "operator=", "struct_identity.html#a64f9786e3b6cd410406d14d124be1e7c", null ],
    [ "namelength", "struct_identity.html#a4232dacf1ace14d82b3fa90b71bf6f17", null ],
    [ "sensorChipSelect", "struct_identity.html#a219419d57e4c4e0d53ddcb44af330f32", null ],
    [ "sensorID", "struct_identity.html#a4f5a5e2cb7ee061dd0bd29b7086d89ac", null ],
    [ "SensorName", "struct_identity.html#a8312ce3b92270e7548eba232df2b90a6", null ]
];