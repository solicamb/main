var class_communicative =
[
    [ "Communicative", "class_communicative.html#aa92e21c2c2b3ee8dda993872f6b0c73a", null ],
    [ "~Communicative", "class_communicative.html#a53c7f2ec58bfb99f0ea10e238705c3ce", null ],
    [ "isPeripheralConnected", "class_communicative.html#ac3d11fc6a7b276a19b1d92cd19e9a046", null ],
    [ "RequestData", "class_communicative.html#a0a56aaa3248edae66ccb13cbf2bf156a", null ],
    [ "RequestIdentity", "class_communicative.html#a01ee3d76d85bad6123c4d4f6262c6c2d", null ],
    [ "RequestReply", "class_communicative.html#a4fe112ad5a3d693e39ae44dd43eaf0c1", null ]
];